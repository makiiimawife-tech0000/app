"""Core trading logic"""
